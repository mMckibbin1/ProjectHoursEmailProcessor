export var Microsoft;
(function (Microsoft) {
    var FluentUI;
    (function (FluentUI) {
        var Blazor;
        (function (Blazor) {
            var Nav;
            (function (Nav) {
                const DURATION_FAST = 100;
                const DURATION_ULTRA_SLOW = 500;
                const CURVE_DECELERATE_MID = 'cubic-bezier(0, 0, 0, 1)';
                const CURVE_ACCELERATE_MIN = 'cubic-bezier(0.8, 0, 0.78, 1)';
                function calculateDuration(itemCount, isSmallDensity) {
                    const durationPerItem = isSmallDensity ? 15 : 25;
                    const baseDuration = DURATION_FAST + itemCount * durationPerItem;
                    return Math.min(baseDuration, DURATION_ULTRA_SLOW);
                }
                function createKeyframes(height) {
                    return [
                        {
                            minHeight: 0,
                            height: 0
                        },
                        {
                            minHeight: `${height}px`,
                            height: `${height}px`
                        }
                    ];
                }
                function AnimateExpand(groupId, density = 'medium') {
                    const group = document.getElementById(groupId);
                    if (!group)
                        return;
                    group.getAnimations().forEach(anim => anim.cancel());
                    const computedStyles = window.getComputedStyle(group);
                    const isAlreadyVisible = computedStyles.overflow === 'visible';
                    if (isAlreadyVisible) {
                        group.style.height = 'auto';
                        group.style.minHeight = 'auto';
                        group.style.opacity = '1';
                        group.style.overflow = 'visible';
                        return;
                    }
                    const itemCount = group.children.length;
                    const isSmallDensity = density === 'small';
                    const targetHeight = group.scrollHeight;
                    const duration = calculateDuration(itemCount, isSmallDensity);
                    const keyframes = createKeyframes(targetHeight);
                    group.style.overflowY = 'hidden';
                    group.style.overflowX = 'visible';
                    const animation = group.animate(keyframes, {
                        duration: duration,
                        easing: CURVE_DECELERATE_MID,
                        fill: 'forwards'
                    });
                    animation.onfinish = () => {
                        group.style.height = 'auto';
                        group.style.minHeight = 'auto';
                        group.style.opacity = '1';
                        group.style.overflow = 'visible';
                        const nav = group.closest('.fluent-nav');
                        if (nav)
                            UpdateTabIndices(nav);
                    };
                }
                Nav.AnimateExpand = AnimateExpand;
                function AnimateCollapse(groupId, density = 'medium') {
                    return new Promise((resolve) => {
                        const group = document.getElementById(groupId);
                        if (!group) {
                            resolve();
                            return;
                        }
                        group.getAnimations().forEach(anim => anim.cancel());
                        const itemCount = group.children.length;
                        const isSmallDensity = density === 'small';
                        const currentHeight = group.scrollHeight;
                        const duration = calculateDuration(itemCount, isSmallDensity);
                        const keyframes = [...createKeyframes(currentHeight)].reverse();
                        group.style.overflowY = 'hidden';
                        group.style.overflowX = 'visible';
                        const animation = group.animate(keyframes, {
                            duration: duration,
                            easing: CURVE_ACCELERATE_MIN,
                            fill: 'forwards'
                        });
                        animation.onfinish = () => {
                            group.style.height = '0px';
                            group.style.minHeight = '0px';
                            group.style.opacity = '0';
                            const nav = group.closest('.fluent-nav');
                            if (nav)
                                UpdateTabIndices(nav);
                            resolve();
                        };
                    });
                }
                Nav.AnimateCollapse = AnimateCollapse;
                const _navControllers = new Map();
                function Initialize(navId) {
                    const nav = document.getElementById(navId);
                    if (!nav)
                        return;
                    _navControllers.get(navId)?.abort();
                    const controller = new AbortController();
                    const { signal } = controller;
                    _navControllers.set(navId, controller);
                    UpdateTabIndices(nav);
                    nav.addEventListener('keydown', (e) => {
                        if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Home' || e.key === 'End') {
                            const target = e.target;
                            if (!target || (!target.classList.contains('fluent-navitem') && !target.classList.contains('fluent-navcategoryitem'))) {
                                return;
                            }
                            const items = getVisibleItems(nav);
                            if (items.length === 0)
                                return;
                            const currentIndex = items.indexOf(target);
                            if (currentIndex === -1)
                                return;
                            e.preventDefault();
                            let nextIndex = currentIndex;
                            if (e.key === 'ArrowDown') {
                                nextIndex = (currentIndex + 1) % items.length;
                            }
                            else if (e.key === 'ArrowUp') {
                                nextIndex = (currentIndex - 1 + items.length) % items.length;
                            }
                            else if (e.key === 'Home') {
                                nextIndex = 0;
                            }
                            else if (e.key === 'End') {
                                nextIndex = items.length - 1;
                            }
                            items[nextIndex].focus();
                        }
                    }, { signal });
                    nav.addEventListener('focusin', (e) => {
                        const target = e.target;
                        if (target.classList.contains('fluent-navitem') || target.classList.contains('fluent-navcategoryitem')) {
                            UpdateTabIndices(nav, target);
                        }
                    }, { signal });
                }
                Nav.Initialize = Initialize;
                function Dispose(navId) {
                    _navControllers.get(navId)?.abort();
                    _navControllers.delete(navId);
                }
                Nav.Dispose = Dispose;
                function getVisibleItems(nav) {
                    return Array.from(nav.querySelectorAll('.fluent-navitem, .fluent-navcategoryitem'))
                        .filter(el => {
                        if (el.classList.contains('disabled'))
                            return false;
                        const parentGroup = el.closest('.fluent-navsubitemgroup');
                        return !parentGroup || parentGroup.classList.contains('expanded');
                    });
                }
                function UpdateTabIndices(nav, activeItem = null) {
                    const items = Array.from(nav.querySelectorAll('.fluent-navitem, .fluent-navcategoryitem'));
                    const visibleItems = getVisibleItems(nav);
                    if (!activeItem) {
                        activeItem = visibleItems.find(el => el.classList.contains('active')) || visibleItems[0];
                    }
                    items.forEach(el => {
                        if (el === activeItem) {
                            el.setAttribute('tabindex', '0');
                        }
                        else {
                            el.setAttribute('tabindex', '-1');
                        }
                    });
                }
            })(Nav = Blazor.Nav || (Blazor.Nav = {}));
        })(Blazor = FluentUI.Blazor || (FluentUI.Blazor = {}));
    })(FluentUI = Microsoft.FluentUI || (Microsoft.FluentUI = {}));
})(Microsoft || (Microsoft = {}));
